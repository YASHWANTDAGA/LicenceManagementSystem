package com.licence.licencemanagementsystem;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.time.LocalDate;
import java.util.*;

public class LicenceApp extends Application {

    private TextArea systemInfoArea, statusArea;
    private TextField usernameField;
    private Label statusLabel, expiryLabel;
    private Button generateButton, verifyButton, sendButton;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Licence Management System");

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));

        usernameField = new TextField();
        usernameField.setPromptText("Enter Username");
        usernameField.setMaxWidth(300);

        systemInfoArea = new TextArea();
        systemInfoArea.setEditable(false);
        systemInfoArea.setPrefHeight(100);
        systemInfoArea.setWrapText(true);

        statusArea = new TextArea();
        statusArea.setEditable(false);
        statusArea.setPrefHeight(100);
        statusArea.setWrapText(true);

        statusLabel = new Label("Status: Not Verified");
        expiryLabel = new Label("Licence Expiry: -");

        HBox buttonBox = new HBox(10);
        generateButton = new Button("Generate Request");
        sendButton = new Button("Send to Server");
        verifyButton = new Button("Verify Licence");
        buttonBox.getChildren().addAll(generateButton, sendButton, verifyButton);

        generateButton.setOnAction(e -> generateActivationRequest());
        verifyButton.setOnAction(e -> verifyLicence());
        sendButton.setOnAction(e -> sendActivationFileToServer());

        root.getChildren().addAll(
                new Label("Username:"), usernameField,
                new Label("System Information:"), systemInfoArea,
                buttonBox,
                new Label("Licence Status:"), statusLabel, expiryLabel,
                new Label("Status Log:"), statusArea
        );

        Scene scene = new Scene(root, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

        displaySystemInfo();
    }

    private void displaySystemInfo() {
        String info = getSystemSignature();
        systemInfoArea.setText(info);
    }

    private String getSystemSignature() {
        try {
            String mac = getMACAddress();
            String cpu = System.getenv("PROCESSOR_IDENTIFIER");
            String os = System.getProperty("os.name") + " " + System.getProperty("os.version");
            return "MAC: " + mac + "\nCPU: " + cpu + "\nOS: " + os;
        } catch (Exception e) {
            return "Error retrieving system info.";
        }
    }

    private String getMACAddress() throws Exception {
        InetAddress ip = InetAddress.getLocalHost();
        NetworkInterface network = NetworkInterface.getByInetAddress(ip);
        byte[] mac = network.getHardwareAddress();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mac.length; i++) {
            sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
        }
        return sb.toString();
    }

    private void generateActivationRequest() {
        try {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                showAlert("Input Error", "Please enter a username.");
                return;
            }

            String sysInfo = getSystemSignature();
            String serial = UUID.randomUUID().toString();

            String userData = "Username: " + username + "\n" +
                    "Serial: " + serial + "\n" +
                    sysInfo;

            String normalizedData = userData.replace("\r\n", "\n");

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(normalizedData.getBytes());
            String key = Base64.getEncoder().encodeToString(hash);

            String content = normalizedData + "\n\nGenerated Key: " + key + "\n";

            Files.write(Paths.get("activation_request.txt"), content.getBytes());
            showAlert("Success", "Activation request file generated.");
            statusArea.appendText("[✔] Activation request generated.\n");

        } catch (Exception e) {
            showAlert("Error", "Failed to generate activation file: " + e.getMessage());
        }
    }

    private void sendActivationFileToServer() {
        try (Socket socket = new Socket("localhost", 5555)) {

            Path path = Paths.get("activation_request.txt");
            if (!Files.exists(path)) {
                showAlert("Error", "Activation file not found.");
                return;
            }

            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            String content = Files.readString(path);
            writer.write(content);
            writer.newLine();
            writer.flush();
            socket.shutdownOutput();

            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            StringBuilder licenceBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                licenceBuilder.append(line).append("\n");
            }

            String licenceContent = licenceBuilder.toString().trim();
            if (!licenceContent.startsWith("LICENCED USER")) {
                showAlert("Error", "Invalid licence file received.");
                return;
            }

            Files.write(Paths.get("client.lic"), licenceContent.getBytes());
            showAlert("Success", "Licence file received and saved as 'client.lic'.");
            statusArea.appendText("[✔] Licence file received from server.\n");

        } catch (IOException e) {
            showAlert("Error", "Failed to send/receive file: " + e.getMessage());
        }
    }

    private void verifyLicence() {
        try {
            Path licencePath = Paths.get("client.lic");
            if (!Files.exists(licencePath)) {
                showAlert("Error", "Licence file not found. Please activate.");
                return;
            }

            String content = Files.readString(licencePath);
            if (!content.startsWith("LICENCED USER")) {
                showAlert("Invalid", "Invalid licence file format.");
                return;
            }

            String[] lines = content.split("\n");
            Map<String, String> data = new HashMap<>();
            for (String line : lines) {
                if (line.contains(":")) {
                    String[] parts = line.split(":", 2);
                    data.put(parts[0].trim(), parts[1].trim());
                }
            }

            String enteredUsername = usernameField.getText().trim();
            if (enteredUsername.isEmpty() || !enteredUsername.equals(data.get("Username"))) {
                showAlert("Invalid", "Username does not match licence.");
                statusLabel.setText("Status: Invalid Username");
                return;
            }

            String mac = getMACAddress();
            String cpu = System.getenv("PROCESSOR_IDENTIFIER");
            String os = System.getProperty("os.name") + " " + System.getProperty("os.version");

            if (!mac.equals(data.get("MAC")) || !cpu.equals(data.get("CPU")) || !os.equals(data.get("OS"))) {
                showAlert("Invalid", "System information does not match licence.");
                statusLabel.setText("Status: Invalid System Info");
                return;
            }

            LocalDate expiry = LocalDate.parse(data.get("Valid Until"));
            if (expiry.isBefore(LocalDate.now())) {
                showAlert("Expired", "Licence has expired.");
                statusLabel.setText("Status: Expired");
                expiryLabel.setText("Licence Expiry: " + expiry);
                return;
            }

            showAlert("Success", "Licence verified successfully.");
            statusLabel.setText("Status: Valid");
            expiryLabel.setText("Licence Expiry: " + expiry);
            statusArea.appendText("[✔] Licence verified and valid until: " + expiry + "\n");

        } catch (Exception e) {
            showAlert("Error", "Verification failed: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}