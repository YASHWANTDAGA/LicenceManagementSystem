package com.licence.adminui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.*;
import java.security.*;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;
import java.util.Base64;

public class AdminUI extends Application {

    private TableView<LicenceEntry> tableView = new TableView<>();
    private TextField searchField = new TextField();
    private TextArea logArea = new TextArea();
    private Thread serverThread;
    private ServerSocket serverSocket;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/licence_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Admin Licence Dashboard");

        HBox topBar = new HBox(10);
        Button addUserButton = new Button("Add New User");
        Button refreshButton = new Button("Refresh List");
        Button revokeButton = new Button("Revoke Selected");
        Button startServerButton = new Button("Start Server");
        Button stopServerButton = new Button("Stop Server");
        searchField.setPromptText("Search by username...");

        addUserButton.setOnAction(e -> showAddUserDialog());
        refreshButton.setOnAction(e -> loadLicenceData());
        revokeButton.setOnAction(e -> revokeSelectedLicence());
        startServerButton.setOnAction(e -> startServer());
        stopServerButton.setOnAction(e -> stopServer());
        searchField.textProperty().addListener((obs, oldText, newText) -> loadLicenceData(newText));

        topBar.getChildren().addAll(addUserButton, refreshButton, revokeButton, startServerButton, stopServerButton, searchField);

        TableColumn<LicenceEntry, String> userCol = new TableColumn<>("Username");
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<LicenceEntry, String> macCol = new TableColumn<>("MAC");
        macCol.setCellValueFactory(new PropertyValueFactory<>("mac"));

        TableColumn<LicenceEntry, String> cpuCol = new TableColumn<>("CPU");
        cpuCol.setCellValueFactory(new PropertyValueFactory<>("cpu"));

        TableColumn<LicenceEntry, String> osCol = new TableColumn<>("OS");
        osCol.setCellValueFactory(new PropertyValueFactory<>("os"));

        TableColumn<LicenceEntry, String> keyCol = new TableColumn<>("Key");
        keyCol.setCellValueFactory(new PropertyValueFactory<>("key"));

        TableColumn<LicenceEntry, String> validCol = new TableColumn<>("Valid Until");
        validCol.setCellValueFactory(new PropertyValueFactory<>("validUntil"));

        tableView.getColumns().addAll(userCol, macCol, cpuCol, osCol, keyCol, validCol);

        logArea.setEditable(false);
        logArea.setPrefHeight(150);

        VBox root = new VBox(10, topBar, tableView, logArea);
        root.setPadding(new Insets(15));

        stage.setScene(new Scene(root, 1000, 600));
        stage.show();

        loadLicenceData();
    }

    private void startServer() {
        serverThread = new Thread(() -> {
            log("Starting Auto Licence Server...");
            try {
                serverSocket = new ServerSocket(5555);
                log("Server started on port 5555.");

                while (!serverSocket.isClosed()) {
                    Socket client = serverSocket.accept();
                    log("Client connected: " + client.getInetAddress());

                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    StringBuilder contentBuilder = new StringBuilder();
                    String line;
                    while ((line = in.readLine()) != null) {
                        contentBuilder.append(line).append("\n");
                    }

                    String content = contentBuilder.toString().replace("\r\n", "\n");
                    log("Received activation request:\n" + content);

                    handleLicenceRequest(content, client);
                    client.close();
                }
            } catch (IOException e) {
                if (!serverSocket.isClosed()) log("Server Error: " + e.getMessage());
            }
        });

        serverThread.setDaemon(true);
        serverThread.start();
    }

    private void stopServer() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
                log("Server stopped.");
            }
        } catch (IOException e) {
            log("Error stopping server: " + e.getMessage());
        }
    }

    private void handleLicenceRequest(String content, Socket clientSocket) {
        try {
            String[] parts = content.split("(?i)Generated Key:\\s*");
            if (parts.length < 2) {
                log("Invalid activation request format.");
                return;
            }

            String userData = parts[0].trim();
            String receivedKey = parts[1].trim();

            String[] lines = userData.split("\n");
            String username = lines[0].split(":", 2)[1].trim();
            String mac = lines[2].split(":", 2)[1].trim();
            String cpu = lines[3].split(":", 2)[1].trim();
            String os = lines[4].split(":", 2)[1].trim();

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(userData.getBytes());
            String calculatedKey = Base64.getEncoder().encodeToString(hash);

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                if (!isValidUsername(conn, username)) {
                    log("Invalid username: " + username);
                    return;
                }

                if (!receivedKey.equals(calculatedKey)) {
                    log("Key mismatch for user: " + username);
                    return;
                }

                if (isSystemAssignedToAnotherUser(conn, username, mac, cpu, os)) {
                    log("System already assigned to another user.");
                    return;
                }

                if (!isExistingLicence(conn, username, mac, cpu, os)) {
                    saveLicenceDetails(conn, username, mac, cpu, os, receivedKey);
                    log("New system registered for user: " + username);
                } else {
                    log("System already registered for user: " + username);
                }

                String validUntil = LocalDate.now().plusYears(1).toString();
                String licenceContent = "LICENCED USER\n" + userData + "\nValid Until: " + validUntil;

                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                out.write(licenceContent);
                out.flush();

                log("Licence file sent to client.");
            }
        } catch (Exception e) {
            log("Error processing request: " + e.getMessage());
        }
    }

    private void showAddUserDialog() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add New User");
        dialog.setHeaderText("Enter new username");

        dialog.showAndWait().ifPresent(username -> {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String sql = "INSERT INTO users(username) VALUES (?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, username);
                    stmt.executeUpdate();
                    showAlert("Success", "User added successfully.");
                }
            } catch (SQLException e) {
                showAlert("DB Error", e.getMessage());
            }
        });
    }

    private void revokeSelectedLicence() {
        LicenceEntry selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a licence to revoke.");
            return;
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "DELETE FROM licence_details WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, selected.getUsername());
                stmt.executeUpdate();
                showAlert("Success", "Licence revoked.");
                loadLicenceData();
            }
        } catch (SQLException e) {
            showAlert("DB Error", e.getMessage());
        }
    }

    private void loadLicenceData() {
        loadLicenceData("");
    }

    private void loadLicenceData(String filter) {
        List<LicenceEntry> entries = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM licence_details WHERE username LIKE ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, "%" + filter + "%");
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    entries.add(new LicenceEntry(
                            rs.getString("username"),
                            rs.getString("mac"),
                            rs.getString("cpu"),
                            rs.getString("os"),
                            rs.getString("key"),
                            rs.getString("valid_until")
                    ));
                }
            }
        } catch (SQLException e) {
            showAlert("DB Error", e.getMessage());
        }
        tableView.getItems().setAll(entries);
    }

    private boolean isValidUsername(Connection conn, String username) throws SQLException {
        String query = "SELECT 1 FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    private boolean isExistingLicence(Connection conn, String username, String mac, String cpu, String os) throws SQLException {
        String query = "SELECT 1 FROM licence_details WHERE username = ? AND mac = ? AND cpu = ? AND os = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, mac);
            stmt.setString(3, cpu);
            stmt.setString(4, os);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    private boolean isSystemAssignedToAnotherUser(Connection conn, String username, String mac, String cpu, String os) throws SQLException {
        String query = "SELECT username FROM licence_details WHERE mac = ? AND cpu = ? AND os = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, mac);
            stmt.setString(2, cpu);
            stmt.setString(3, os);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String existingUser = rs.getString("username");
                return !existingUser.equals(username);
            }
            return false;
        }
    }

    private void saveLicenceDetails(Connection conn, String username, String mac, String cpu, String os, String key) throws SQLException {
        String insert = "INSERT INTO licence_details (username, mac, cpu, os, `key`, valid_until) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(insert)) {
            stmt.setString(1, username);
            stmt.setString(2, mac);
            stmt.setString(3, cpu);
            stmt.setString(4, os);
            stmt.setString(5, key);
            stmt.setDate(6, Date.valueOf(LocalDate.now().plusYears(1)));
            stmt.executeUpdate();
        }
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void log(String message) {
        javafx.application.Platform.runLater(() -> logArea.appendText(message + "\n"));
    }

    public static class LicenceEntry {
        private final String username, mac, cpu, os, key, validUntil;

        public LicenceEntry(String username, String mac, String cpu, String os, String key, String validUntil) {
            this.username = username;
            this.mac = mac;
            this.cpu = cpu;
            this.os = os;
            this.key = key;
            this.validUntil = validUntil;
        }

        public String getUsername() { return username; }
        public String getMac() { return mac; }
        public String getCpu() { return cpu; }
        public String getOs() { return os; }
        public String getKey() { return key; }
        public String getValidUntil() { return validUntil; }
    }
}
